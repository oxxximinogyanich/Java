public class Main {
    public static void main(String[] args) {
        String fullName = "Абдыкалык Бакыткелды";
        String group = "ИС-21-25";
        String program = "Программное обеспечение";

        System.out.println("=== Информация о студенте ===");
        System.out.println("ФИО: " + fullName);
        System.out.println("Группа: " + group);
        System.out.println("Специальность: " + program);
    }
}
